import pandas as pd
import numpy as np

def generate_diabetes_dataset(n_samples=1000):
    """
    Generate a synthetic dataset for Smart Diabetic Analysis
    """
    np.random.seed(42)
    
    # Generate synthetic features
    age = np.random.normal(45, 15, n_samples)
    bmi = np.random.normal(25, 5, n_samples)
    glucose = np.random.normal(110, 25, n_samples)
    blood_pressure = np.random.normal(130, 20, n_samples)
    
    # Create synthetic diabetes risk
    diabetes_risk = (
        0.5 * (age > 45) + 
        0.3 * (bmi > 25) + 
        0.4 * (glucose > 125) + 
        0.2 * (blood_pressure > 140)
    )
    
    # Binary diabetes target
    diabetes = (diabetes_risk > np.median(diabetes_risk)).astype(int)
    
    # Create DataFrame
    df = pd.DataFrame({
        'age': age,
        'bmi': bmi,
        'glucose': glucose,
        'blood_pressure': blood_pressure,
        'diabetes': diabetes
    })
    
    # Save dataset
    df.to_csv('smart_diabetic_dataset.csv', index=False)
    print("🩺 Smart Diabetic Analysis Dataset Generated!")
    print(df.head())
    print("\nDataset Statistics:")
    print(df['diabetes'].value_counts(normalize=True))

if __name__ == "__main__":
    generate_diabetes_dataset() 
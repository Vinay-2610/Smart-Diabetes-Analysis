# Ensure Streamlit is imported first
import streamlit as st

# Now add the page configuration
st.set_page_config(page_title="Elevium: Smart Healthcare Solutions", layout="wide", page_icon="🩺")

import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objs as go
import plotly.figure_factory as ff
from scipy.stats import gaussian_kde
import base64
from PIL import Image
import io
import random
import re
import json
import google.generativeai as genai
from datetime import datetime

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix
import xgboost as xgb

from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.platypus import Image
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT

# Configure Gemini API
def setup_gemini_api():
    try:
        api_key = "AIzaSyD7LDe2YYQwvRYELLNQ4o2h0OZHm_zAp94"
        if not api_key:
            raise ValueError("Invalid API key")
        
        # Configure with specific API version
        genai.configure(api_key=api_key)
        
        # Safety settings for the model
        safety_settings = [
            {
                "category": "HARM_CATEGORY_HARASSMENT",
                "threshold": "BLOCK_MEDIUM_AND_ABOVE"
            },
            {
                "category": "HARM_CATEGORY_HATE_SPEECH",
                "threshold": "BLOCK_MEDIUM_AND_ABOVE"
            },
            {
                "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
                "threshold": "BLOCK_MEDIUM_AND_ABOVE"
            },
            {
                "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
                "threshold": "BLOCK_MEDIUM_AND_ABOVE"
            }
        ]
        
        # Initialize model with safety settings
        global generation_config
        generation_config = {
            "temperature": 0.7,
            "top_p": 0.8,
            "top_k": 40,
            "max_output_tokens": 2048,
        }
        
        return True
    except Exception as e:
        st.error(f"""
        ### ⚠️ Gemini API Configuration Error
        
        Unable to initialize the AI Health Assistant. Please ensure:
        
        1. You have a valid API key in `.streamlit/secrets.toml`
        2. Your API key has access to the Gemini API
        3. You're using a supported region
        
        Error details: {str(e)}
        
        Need help? Visit: https://makersuite.google.com/app/apikey
        """)
        return False

# Initialize API configuration
GEMINI_API_CONFIGURED = setup_gemini_api()

def get_gemini_response(question):
    """Get response from Gemini AI model with medical context"""
    if not GEMINI_API_CONFIGURED:
        return """
        ### ⚠️ AI Assistant Not Available
        
        The AI Health Assistant is currently unavailable due to configuration issues.
        Please check the error message above for details.
        """
    
    try:
        # Define safety settings for the model
        safety_settings = [
            {
                "category": "HARM_CATEGORY_HARASSMENT",
                "threshold": "BLOCK_MEDIUM_AND_ABOVE"
            },
            {
                "category": "HARM_CATEGORY_HATE_SPEECH",
                "threshold": "BLOCK_MEDIUM_AND_ABOVE"
            },
            {
                "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
                "threshold": "BLOCK_MEDIUM_AND_ABOVE"
            },
            {
                "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
                "threshold": "BLOCK_MEDIUM_AND_ABOVE"
            }
        ]

        # Define generation config
        generation_config = {
            "temperature": 0.7,
            "top_p": 0.8,
            "top_k": 40,
            "max_output_tokens": 2048,
        }
        
        # Create a new model instance for each request
        model = genai.GenerativeModel(
            model_name='gemini-2.0-flash',
            generation_config=generation_config,
            safety_settings=safety_settings
        )
        
        # Add medical context to the prompt
        prompt = f"""You are a specialized medical AI assistant focused on diabetes care and health management. 
        Please provide a clear, structured response to the following question about diabetes, health, or nutrition.
        
        Format your response with:
        - Clear sections using emoji headers
        - Bullet points for key information
        - Important values or numbers in bold
        - Medical disclaimers when needed
        
        If discussing glucose levels or medical values, always include normal ranges and interpretations.
        If providing health advice, always structure it as:
        1. Main recommendation
        2. How to implement it
        3. Expected benefits
        4. Precautions or warnings
        
        Question: {question}
        """
        
        # Generate response with proper error handling
        response = model.generate_content(prompt)
        if response and response.text:
            return response.text
        else:
            raise ValueError("Empty response received from the model")
            
    except Exception as e:
        error_message = str(e)
        if "404" in error_message:
            return """
            ### ⚠️ Model Access Error
            
            Unable to access the Gemini Pro model. Please ensure:
            1. Your API key is valid and has access to Gemini Pro
            2. You're in a supported region
            3. The service is available in your area
            
            Try regenerating your API key at: https://makersuite.google.com/app/apikey
            """
        else:
            return f"""
            ### ⚠️ Error
            
            An error occurred while generating the response:
            {error_message}
            
            Please try again or contact support if the issue persists.
            """

def initialize_chat_history():
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []

def display_chat_interface():
    st.markdown("""
    <style>
    .chat-container {
        background-color: #1a1a1a;
        border-radius: 10px;
        padding: 20px;
        margin: 10px 0;
    }
    .user-message {
        background-color: #2ecc71;
        color: white;
        padding: 15px;
        border-radius: 15px;
        margin: 10px 0;
        max-width: 80%;
        margin-left: auto;
        font-size: 16px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    }
    .bot-message {
        background-color: #2c3e50;
        color: white;
        padding: 20px;
        border-radius: 15px;
        margin: 10px 0;
        max-width: 90%;
        border: 1px solid #34495e;
        font-size: 16px;
        line-height: 1.6;
        box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    }
    .bot-message h3 {
        color: #3498db;
        margin-top: 15px;
        margin-bottom: 10px;
        font-size: 18px;
        font-weight: bold;
    }
    .bot-message ul {
        margin-left: 20px;
        margin-bottom: 15px;
        color: #ecf0f1;
    }
    .bot-message li {
        margin-bottom: 8px;
    }
    .bot-message strong {
        color: #e74c3c;
        font-weight: bold;
    }
    .bot-message em {
        color: #f1c40f;
        font-style: normal;
        font-weight: bold;
    }
    .chat-input {
        border-radius: 20px;
        border: 2px solid #2ecc71;
        padding: 15px;
        font-size: 16px;
        margin-top: 20px;
        width: 100%;
        background-color: #2c3e50;
        color: white;
    }
    .chat-input::placeholder {
        color: #95a5a6;
    }
    .disclaimer {
        font-size: 0.9em;
        color: #95a5a6;
        font-style: italic;
        background-color: #2c3e50;
        padding: 10px;
        border-radius: 10px;
        margin-top: 20px;
        border: 1px solid #34495e;
    }
    .send-button {
        background-color: #2ecc71;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 20px;
        cursor: pointer;
        font-size: 16px;
        font-weight: bold;
        transition: all 0.3s ease;
        width: 100%;
    }
    .send-button:hover {
        background-color: #27ae60;
        transform: translateY(-2px);
    }
    </style>
    """, unsafe_allow_html=True)

    st.markdown("## 🤖 AI Health Assistant")
    st.markdown("Ask me anything about diabetes, nutrition, medication, or general health advice!")

    # Initialize chat history
    initialize_chat_history()

    # Display chat history
    for message in st.session_state.chat_history:
        if message["role"] == "user":
            st.markdown(f'<div class="user-message">{message["content"]}</div>', unsafe_allow_html=True)
        else:
            # Process the bot's response to add emoji headers and format important information
            response = message["content"]
            # Add emoji to headers if not present
            response = re.sub(r'^(#+)\s*(?![🩺🌟⚕️🔬📊🚨💊🥗🧘‍♂️])', r'\1 🩺 ', response, flags=re.MULTILINE)
            # Highlight numbers and units
            response = re.sub(r'(\d+(?:\.\d+)?(?:\s*(?:mg/dL|g/dL|mmHg|kg/m²|%|minutes|hours|days|weeks))?)', r'<strong>\1</strong>', response)
            # Highlight important terms
            response = re.sub(r'\b(normal|high|low|severe|moderate|urgent|important|warning|caution|recommended)\b', r'<em>\1</em>', response, flags=re.IGNORECASE)
            
            st.markdown(f'<div class="bot-message">{response}</div>', unsafe_allow_html=True)

    # Chat input
    with st.container():
        col1, col2 = st.columns([4, 1])
        with col1:
            user_input = st.text_input("Type your health-related question here...", 
                key="chat_input",
                placeholder="e.g., What are normal blood sugar levels? What diet should I follow?",
                label_visibility="collapsed")
        with col2:
            send_button = st.button("Send", key="send_button", use_container_width=True)

    if send_button and user_input:
        # Add user message to chat history
        st.session_state.chat_history.append({"role": "user", "content": user_input})
        
        # Show typing indicator
        with st.spinner("AI Assistant is thinking..."):
            # Get AI response
            response = get_gemini_response(user_input)
        
        # Add AI response to chat history
        st.session_state.chat_history.append({"role": "assistant", "content": response})
        
        # Clear input and rerun to update chat
        st.rerun()

    # Medical Disclaimer
    st.markdown("""
    <div class="disclaimer">
    ⚕️ <strong>Medical Disclaimer:</strong> This AI assistant provides general information and guidance only. 
    It should not replace professional medical advice, diagnosis, or treatment. 
    Always consult with qualified healthcare providers for medical decisions.
    </div>
    """, unsafe_allow_html=True)

class SmartDiabeticAnalysis:
    def __init__(self):
        # Custom CSS for logo and banner
        st.markdown("""
        <style>
        .logo-container {
            display: flex;
            align-items: center;
          
            padding: 2      0px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .logo-container img {
            height: 80px;
            object-fit: contain;
            margin-right: 15px;
            
        }
        .logo-text {
            display: flex;
            flex-direction: column;
        }
        .logo-main {
            font-size: 20px;
            font-weight: bold;
            color: #2980b9;
        }
        .logo-subtitle {
            font-size: 12px;
            color: #7f8c8d;
        }
        .banner-image {
            width: 30%;
            max-height: 300px;
            object-fit: cover;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                    
        }
        </style>
        """, unsafe_allow_html=True)
        
        # Prepare logos
        try:
            # Kalasalingam logo
            kalasalingam_logo_path = r"C:\Users\findy\OneDrive\Desktop\DIABETIC.PY\maxresdefault.jpg"
            with open(kalasalingam_logo_path, "rb") as logo_file:
                kalasalingam_logo_base64 = base64.b64encode(logo_file.read()).decode()
            
            # Banner image
            banner_path = r"C:\Users\findy\OneDrive\Desktop\DIABETIC.PY\images.png"
            with open(banner_path, "rb") as banner_file:
                banner_base64 = base64.b64encode(banner_file.read()).decode()
            
            # Display logo and banner
            st.markdown(f"""
            <div class="logo-container">
                <img src="data:image/png;base64,{kalasalingam_logo_base64}" alt="Kalasalingam Academy Logo">
                <div class="logo-text">
                    <span class="logo-main">KARE</span>
                    <span class="logo-subtitle">Smart Healthcare Solutions</span>
                </div>
            </div>
            
            <img src="data:image/jpeg;base64,{banner_base64}" class="banner-image" alt="Diabetes Management Banner">
            """, unsafe_allow_html=True)
        
        except Exception as e:
            st.warning(f"Could not load images: {e}")
        
        st.title("🩺 Smart Diabetic Analysis")
        st.write("A comprehensive tool for diabetes risk assessment and prediction.")
        
        # Initialize session state
        if 'model_trained' not in st.session_state:
            st.session_state.model_trained = False
            st.session_state.model = None
            st.session_state.scaler = None
            st.session_state.label_encoder = None
            st.session_state.uploaded_file = None
            st.session_state.feature_names = None
            st.session_state.original_data = None

    def load_and_preprocess_data(self, uploaded_file):
        try:
            # Read the CSV file
            df = pd.read_csv(uploaded_file)
            
            # Store original data in session state
            st.session_state.original_data = df.copy()
            
            # Basic data cleaning
            df.dropna(inplace=True)
            
            # Check for diabetes column with different possible names
            diabetes_column = None
            possible_names = ['diabetes', 'Diabetes', 'diabetic', 'Diabetic', 'Outcome', 'outcome']
            
            for name in possible_names:
                if name in df.columns:
                    diabetes_column = name
                    break
            
            if diabetes_column is None:
                st.error("No diabetes/outcome column found in the dataset. Please ensure your dataset has a column indicating diabetes status.")
                return None, None, None, None, None
            
            # Encode categorical variables
            le = LabelEncoder()
            categorical_columns = df.select_dtypes(include=['object']).columns
            for col in categorical_columns:
                df[col] = le.fit_transform(df[col].astype(str))
            
            # Separate features and target
            X = df.drop(diabetes_column, axis=1)
            y = df[diabetes_column]
            
            # Scale features
            scaler = StandardScaler()
            X_scaled = scaler.fit_transform(X)
            
            return df, X_scaled, y, scaler, X.columns

        except Exception as e:
            st.error(f"Error processing data: {str(e)}")
            return None, None, None, None, None

    def visualize_dataset(self, df):
        # Removed subheader text
        
        # Create tabs for different visualizations
        tab1, tab2, tab3 = st.tabs(["📊 Health Indicators", "🚨 Risk Assessment", "🩺 Diabetes Management"])
        
        with tab1:
            # Create containers for each health indicator
            col1, col2, col3 = st.columns(3)
            
            features = ['glucose', 'bmi', 'blood_pressure']
            feature_labels = {
                'glucose': 'Glucose Levels',
                'bmi': 'Body Mass Index (BMI)',
                'blood_pressure': 'Blood Pressure'
            }
            
            colors = ['#3498db', '#e74c3c', '#2ecc71']
            
            def create_age_bins(series):
                bins = [0, 20, 30, 40, 50, 60, 70, 80, 90, 100]
                labels = ['0-20', '21-30', '31-40', '41-50', '51-60', '61-70', '71-80', '81-90', '91-100']
                return pd.cut(series, bins=bins, labels=labels, right=False)
            
            for feature, color, col in zip(features, colors, [col1, col2, col3]):
                with col:
                    st.markdown(f"### 🩺 {feature_labels[feature]} Analysis")
                    
                    # Create figure
                    fig = go.Figure()
                    
                    # Group data by age and calculate mean
                    diabetic_grouped = df[df['diabetes'] == 1].groupby(create_age_bins(df[df['diabetes'] == 1]['age']))[feature].mean()
                    non_diabetic_grouped = df[df['diabetes'] == 0].groupby(create_age_bins(df[df['diabetes'] == 0]['age']))[feature].mean()
                    
                    # Add traces
                    fig.add_trace(go.Scatter(
                        x=non_diabetic_grouped.index, 
                        y=non_diabetic_grouped.values,
                        mode='lines+markers',
                        name='No Diabetes',
                        line=dict(color=color, dash='dot'),
                        marker=dict(size=8, symbol='circle')
                    ))
                    
                    fig.add_trace(go.Scatter(
                        x=diabetic_grouped.index, 
                        y=diabetic_grouped.values,
                        mode='lines+markers',
                        name='Diabetes',
                        line=dict(color=color),
                        marker=dict(size=10, symbol='star')
                    ))
                    
                    # Update layout
                    fig.update_layout(
                        title=f'Age vs {feature_labels[feature]}',
                        xaxis_title='Age Groups',
                        yaxis_title=feature_labels[feature],
                        height=400,
                        width=350,
                        template='plotly_white'
                    )
                    
                    # Display the plot
                    st.plotly_chart(fig, use_container_width=True)
        
        with tab2:
            st.markdown("# 📊 Risk Calculation Methodology")
            
            # Enhanced Risk Factors with Detailed Insights
            risk_factors = [
                {
                    'emoji': '🩸',
                    'title': 'Glucose Levels',
                    'weight': 30,
                    'description': """
                    Glucose levels are a critical indicator of metabolic health. 
                    Elevated blood sugar can signal potential diabetes risk and 
                    impact various bodily functions.
                    """,
                    'risk_ranges': [
                        {'level': 'Normal', 'range': '70-99 mg/dL', 'score': 0},
                        {'level': 'Prediabetes', 'range': '100-125 mg/dL', 'score': 15},
                        {'level': 'High Risk', 'range': '> 126 mg/dL', 'score': 30}
                    ]
                },
                {
                    'emoji': '📏',
                    'title': 'Body Mass Index (BMI)',
                    'weight': 25,
                    'description': """
                    BMI provides insights into body composition and potential 
                    health risks associated with weight. It's a key indicator 
                    of metabolic health and diabetes susceptibility.
                    """,
                    'risk_ranges': [
                        {'level': 'Healthy', 'range': '18.5-24.9', 'score': 0},
                        {'level': 'Overweight', 'range': '25-29.9', 'score': 15},
                        {'level': 'Obese', 'range': '≥ 30', 'score': 25}
                    ]
                },
                {
                    'emoji': '🕰️',
                    'title': 'Age',
                    'weight': 20,
                    'description': """
                    Age is a significant risk factor for diabetes. 
                    As individuals age, the risk of developing metabolic 
                    disorders increases due to physiological changes.
                    """,
                    'risk_ranges': [
                        {'level': 'Low Risk', 'range': '< 40 years', 'score': 0},
                        {'level': 'Moderate Risk', 'range': '40-50 years', 'score': 10},
                        {'level': 'High Risk', 'range': '> 50 years', 'score': 20}
                    ]
                },
                {
                    'emoji': '❤️',
                    'title': 'Blood Pressure',
                    'weight': 15,
                    'description': """
                    Blood pressure is closely linked to metabolic health. 
                    Hypertension can be both a risk factor for and a 
                    consequence of diabetes.
                    """,
                    'risk_ranges': [
                        {'level': 'Normal', 'range': '< 120/80 mmHg', 'score': 0},
                        {'level': 'Elevated', 'range': '120-129/< 80 mmHg', 'score': 10},
                        {'level': 'High', 'range': '≥ 130/80 mmHg', 'score': 15}
                    ]
                }
            ]

            # Render Risk Factors with Detailed Insights
            for factor in risk_factors:
                with st.expander(f"{factor['emoji']} {factor['title']} (Weight: {factor['weight']}%)"):
                    # Description
                    st.markdown(f"### 📋 Overview\n{factor['description']}")
                    
                    # Risk Ranges Table
                    st.markdown("### 🎯 Risk Ranges")
                    risk_df = pd.DataFrame(factor['risk_ranges'])
                    st.table(risk_df)
                    
                    # Visual Risk Distribution
                    fig = px.bar(
                        risk_df, 
                        x='level', 
                        y='score', 
                        title=f'Risk Scoring for {factor["title"]}',
                        labels={'level': 'Risk Level', 'score': 'Risk Score'},
                        color='level',
                        color_discrete_map={
                            'Normal': '#2ecc71', 
                            'Low Risk': '#2ecc71', 
                            'Healthy': '#2ecc71',
                            'Prediabetes': '#f39c12', 
                            'Moderate Risk': '#f39c12', 
                            'Overweight': '#f39c12',
                            'High Risk': '#e74c3c', 
                            'Obese': '#e74c3c', 
                            'Elevated': '#e74c3c'
                        }
                    )
                    st.plotly_chart(fig, use_container_width=True)

            # Comprehensive Risk Calculation Function
            def calculate_comprehensive_risk_score(glucose, bmi, age, blood_pressure):
                def calculate_glucose_risk(glucose):
                    if glucose > 126: return 30
                    if glucose > 100: return 15
                    return 0

                def calculate_bmi_risk(bmi):
                    if bmi > 30: return 25
                    if bmi > 25: return 15
                    return 0

                def calculate_age_risk(age):
                    if age > 50: return 20
                    if age > 40: return 10
                    return 0

                def calculate_bp_risk(bp):
                    if bp > 140: return 15
                    if bp > 130: return 10
                    return 0

                total_score = (
                    calculate_glucose_risk(glucose) +
                    calculate_bmi_risk(bmi) +
                    calculate_age_risk(age) +
                    calculate_bp_risk(blood_pressure)
                )
                return total_score

            # Risk Score Interpretation
            st.markdown("## 🎲 Risk Score Interpretation")
            risk_interpretation = [
                {
                    'range': '0-20',
                    'level': 'Low Risk',
                    'description': 'Excellent metabolic health. Continue current lifestyle and preventive practices.',
                    'color': '#2ecc71'
                },
                {
                    'range': '21-40',
                    'level': 'Moderate Risk',
                    'description': 'Some health improvements recommended. Consult healthcare professional for personalized guidance.',
                    'color': '#f39c12'
                },
                {
                    'range': '41-60',
                    'level': 'High Risk',
                    'description': 'Significant health risks detected. Immediate lifestyle modifications and medical consultation advised.',
                    'color': '#e74c3c'
                }
            ]

            # Risk Interpretation Table
            risk_interp_df = pd.DataFrame(risk_interpretation)
            st.table(risk_interp_df)

            # Visualization of Risk Levels
            fig_risk_levels = px.bar(
                risk_interp_df, 
                x='range', 
                y=[1,1,1],  # Equal heights to show levels
                title='Risk Level Distribution',
                labels={'range': 'Risk Score Range', 'value': 'Risk Level'},
                color='level',
                color_discrete_map={
                    'Low Risk': '#2ecc71', 
                    'Moderate Risk': '#f39c12', 
                    'High Risk': '#e74c3c'
                }
            )
            st.plotly_chart(fig_risk_levels, use_container_width=True)

            # Medical Disclaimer with Enhanced Formatting
            st.warning("""
            🩺 **Medical Disclaimer**: 
            This risk assessment is a comprehensive guide designed to provide insights into potential health risks. 
            It is NOT a definitive medical diagnosis. 
            
            Key Points:
            - Individual health varies significantly
            - Professional medical consultation is crucial
            - Use this assessment as a starting point for proactive health management
            
            Always consult with a healthcare provider for personalized medical guidance, 
            comprehensive evaluation, and tailored health recommendations.
            """)

            # Optional Risk Reduction Strategies
            st.markdown("## 🛡️ Risk Reduction Strategies")
            risk_reduction_tips = [
                {
                    'category': 'Nutrition',
                    'tips': [
                        'Adopt a low-glycemic index diet',
                        'Increase fiber and whole grain intake',
                        'Limit processed and sugary foods',
                        'Practice portion control'
                    ]
                },
                {
                    'category': 'Physical Activity',
                    'tips': [
                        'Aim for 150 minutes of moderate exercise weekly',
                        'Include both cardio and strength training',
                        'Practice regular walking',
                        'Reduce sedentary time'
                    ]
                },
                {
                    'category': 'Stress Management',
                    'tips': [
                        'Practice daily meditation',
                        'Ensure 7-9 hours of quality sleep',
                        'Try yoga or mindfulness techniques',
                        'Maintain a supportive social network'
                    ]
                }
            ]

            # Render Risk Reduction Tips
            cols = st.columns(3)
            for i, strategy in enumerate(risk_reduction_tips):
                with cols[i]:
                    with st.expander(f"🌟 {strategy['category']} Strategies"):
                        for tip in strategy['tips']:
                            st.markdown(f"- {tip}")
        
        # Add Report Generation Section Below Tabs
        st.markdown("## 📄 Comprehensive Health Report")
        st.markdown("Generate a detailed PDF report summarizing your health insights and analysis.")
        
        # Create columns for report button
        report_col1, report_col2, report_col3 = st.columns([1,3,1])
        
        with report_col2:
            generate_report = st.button(
                "🔬 Generate Comprehensive Health Report", 
                key="generate_report_btn_tabs", 
                help="Click to create a downloadable PDF with your health analysis",
                use_container_width=True
            )
        
        # Process report generation
        if generate_report:
            try:
                # Load the original dataset
                original_df = st.session_state.original_data
                
                # Generate report
                report_bytes = HealthReportGenerator.generate_comprehensive_report(original_df)
                
                # Create download link
                download_link = HealthReportGenerator.create_download_link(report_bytes)
                
                # Display download link with success message
                st.success("🎉 Your comprehensive health report has been generated!")
                st.markdown(download_link, unsafe_allow_html=True)
            
            except Exception as e:
                st.error(f"Error generating report: {e}")
        
        # Remaining tab content for tab3 (Diabetes Management)
        with tab3:
            st.markdown("# 🩺 Comprehensive Diabetes Management Guide")
            
            # Detailed Management Sections
            management_sections = [
                {
                    'title': 'Blood Sugar Monitoring',
                    'emoji': '🩸',
                    'overview': """
                    Effective blood sugar monitoring is the cornerstone of diabetes management. 
                    It provides real-time insights into your metabolic health and helps prevent 
                    potential complications.
                    """,
                    'key_strategies': [
                        {
                            'name': 'Daily Monitoring Techniques',
                            'details': [
                                'Use glucometer for traditional testing',
                                'Explore continuous glucose monitoring (CGM) systems',
                                ('Track readings at consistent times: '
                                 '- Fasting '
                                 '- Before meals '
                                 '- 2 hours after meals '
                                 '- Before bedtime')
                            ],
                            'recommended_devices': [
                                'FreeStyle Libre',
                                'Dexcom G6',
                                'Medtronic Guardian',
                                'Traditional Glucometers'
                            ]
                        },
                        {
                            'name': 'Monitoring Targets and Interpretation',
                            'details': [
                                'Fasting Glucose: 80-130 mg/dL',
                                'Post-Meal Glucose: < 180 mg/dL',
                                'HbA1c: < 7% for most adults',
                                ('Individualized targets based on: '
                                 '- Age '
                                 '- Overall health '
                                 '- Diabetes duration '
                                 '- Presence of complications')
                            ],
                            'risk_levels': [
                                {'level': 'Low Risk', 'range': '80-130 mg/dL'},
                                {'level': 'Moderate Risk', 'range': '130-180 mg/dL'},
                                {'level': 'High Risk', 'range': '> 180 mg/dL'}
                            ]
                        }
                    ],
                    'consequences': [
                        {
                            'condition': 'Hyperglycemia (High Blood Sugar)',
                            'symptoms': [
                                'Excessive thirst',
                                'Frequent urination',
                                'Blurred vision',
                                'Fatigue',
                                'Slow wound healing'
                            ],
                            'long_term_risks': [
                                'Cardiovascular disease',
                                'Kidney damage',
                                'Nerve damage',
                                'Vision problems',
                                'Increased infection risk'
                            ]
                        },
                        {
                            'condition': 'Hypoglycemia (Low Blood Sugar)',
                            'symptoms': [
                                'Shakiness',
                                'Sweating',
                                'Confusion',
                                'Dizziness',
                                'Weakness',
                                'Rapid heartbeat'
                            ],
                            'immediate_actions': [
                                'Consume 15g fast-acting carbohydrates',
                                'Recheck blood sugar after 15 minutes',
                                'Have emergency glucose sources nearby'
                            ]
                        }
                    ]
                }
            ]

            # Create two columns for management sections
            col1, col2 = st.columns([1, 1])

            with col1:
                # Blood Sugar Monitoring Section
                st.markdown("## 🩸 Blood Sugar Monitoring")
                
                # Overview Expander
                with st.expander("📝 Monitoring Overview"):
                    st.markdown(management_sections[0]['overview'])
                
                # Daily Monitoring Strategies
                with st.expander("📊 Daily Monitoring Techniques"):
                    st.markdown("### Monitoring Methods")
                    for detail in management_sections[0]['key_strategies'][0]['details']:
                        st.markdown(f"- {detail}")
                    
                    st.markdown("\n### Recommended Devices")
                    for device in management_sections[0]['key_strategies'][0]['recommended_devices']:
                        st.markdown(f"- {device}")
                
                # Monitoring Targets
                with st.expander("🎯 Monitoring Targets"):
                    st.markdown("### Glucose Level Goals")
                    for detail in management_sections[0]['key_strategies'][1]['details']:
                        st.markdown(f"- {detail}")
                    
                    st.markdown("\n### Risk Levels")
                    risk_data = management_sections[0]['key_strategies'][1]['risk_levels']
                    risk_df = pd.DataFrame(risk_data)
                    st.table(risk_df)

            with col2:
                # Consequences and Management
                st.markdown("## 🚨 Blood Sugar Complications")
                
                # Hyperglycemia Details
                with st.expander("📈 Hyperglycemia Insights"):
                    hyper_data = management_sections[0]['consequences'][0]
                    st.markdown(f"### {hyper_data['condition']}")
                    
                    st.markdown("#### Symptoms")
                    for symptom in hyper_data['symptoms']:
                        st.markdown(f"- {symptom}")
                    
                    st.markdown("\n#### Long-Term Risks")
                    for risk in hyper_data['long_term_risks']:
                        st.markdown(f"- {risk}")
                
                # Hypoglycemia Details
                with st.expander("📉 Hypoglycemia Management"):
                    hypo_data = management_sections[0]['consequences'][1]
                    st.markdown(f"### {hypo_data['condition']}")
                    
                    st.markdown("#### Symptoms")
                    for symptom in hypo_data['symptoms']:
                        st.markdown(f"- {symptom}")
                    
                    st.markdown("\n#### Immediate Actions")
                    for action in hypo_data['immediate_actions']:
                        st.markdown(f"- {action}")

            # Lifestyle Management
            st.markdown("## 🌈 Holistic Lifestyle Management")
            
            lifestyle_tips = [
                {
                    'category': 'Nutrition',
                    'emoji': '🥗',
                    'detailed_description': """
                    Nutrition plays a critical role in diabetes management. 
                    A well-planned diet can help stabilize blood sugar levels, 
                    improve insulin sensitivity, and reduce the risk of complications.
                    """,
                    'tips': [
                        'Follow a low-glycemic index diet',
                        'Increase fiber intake',
                        'Limit processed and sugary foods',
                        'Practice portion control',
                        'Balance macronutrients',
                        'Stay hydrated'
                    ],
                    'recommended_foods': [
                        'Leafy green vegetables',
                        'Whole grains',
                        'Lean proteins',
                        'Nuts and seeds',
                        'Berries'
                    ]
                },
                {
                    'category': 'Physical Activity',
                    'emoji': '🏃',
                    'detailed_description': """
                    Regular physical activity is essential for diabetes management. 
                    Exercise helps improve insulin sensitivity, reduces blood sugar levels, 
                    and supports overall metabolic health.
                    """,
                    'tips': [
                        'Aim for 150 minutes of moderate exercise weekly',
                        'Include both cardio and strength training',
                        'Practice regular walking',
                        'Stay consistently active'
                    ]
                },
                {
                    'category': 'Stress Management',
                    'emoji': '🧘',
                    'detailed_description': """
                    Stress can significantly impact blood sugar levels and overall diabetes management. 
                    Implementing effective stress reduction techniques helps maintain metabolic balance 
                    and supports mental well-being.
                    """,
                    'tips': [
                        'Practice daily meditation',
                        'Ensure 7-9 hours of quality sleep',
                        'Try yoga or mindfulness techniques',
                        'Maintain a supportive social network'
                    ]
                }
            ]

            # Render Lifestyle Tips
            cols = st.columns(3)
            for i, lifestyle in enumerate(lifestyle_tips):
                with cols[i]:
                    with st.expander(f"{lifestyle['emoji']} {lifestyle['category']} Guide"):
                        st.markdown(lifestyle['detailed_description'])
                        st.markdown("### Key Tips")
                        for tip in lifestyle['tips']:
                            st.markdown(f"- {tip}")
                        
                        if 'recommended_foods' in lifestyle:
                            st.markdown("### Recommended Foods")
                            for food in lifestyle['recommended_foods']:
                                st.markdown(f"- {food}")

            # Emergency Management
            st.markdown("## 🚨 Emergency Management")
            
            emergency_steps = [
                {
                    'title': 'Recognize Symptoms',
                    'description': 'Learn to identify early signs of blood sugar fluctuations',
                    'details': [
                        'Understand hyperglycemia and hypoglycemia symptoms',
                        'Track your body\'s unique response patterns'
                    ]
                },
                {
                    'title': 'Emergency Preparedness',
                    'description': 'Always be ready to manage unexpected situations',
                    'details': [
                        'Keep emergency glucose sources nearby',
                        'Wear a medical identification bracelet',
                        'Maintain an emergency contact list',
                        'Know when to seek immediate medical help'
                    ]
                }
            ]
            
            with st.expander("🆘 Emergency Preparedness Guide"):
                for step in emergency_steps:
                    st.markdown(f"### {step['title']}")
                    st.markdown(step['description'])
                    for detail in step['details']:
                        st.markdown(f"- {detail}")

            # Medical Disclaimer
            st.warning("""
            🩺 **Medical Disclaimer**: 
            This comprehensive guide is for informational purposes only. 
            Diabetes management is highly individualized. Always consult with 
            healthcare professionals for personalized advice, diagnosis, 
            and tailored treatment plans.
            """)

    def plot_variable_relationship(self, df):
        # Select numeric columns excluding the target variable
        numeric_cols = df.select_dtypes(include=['float64', 'int64']).columns.tolist()
        numeric_cols = [col for col in numeric_cols if col != 'diabetes']
        
        # Create a comprehensive line graph and insights
        st.subheader("Variable Relationships and Health Insights")
        
        # Create figure with subplots
        fig = go.Figure()
        
        # Prepare insights and recommendations
        insights = []
        recommendations = []
        
        # Add lines for each numeric feature
        for feature in numeric_cols:
            # Calculate mean and percentile values for diabetic and non-diabetic groups
            diabetic_percentiles = np.percentile(df[df['diabetes'] == 1][feature], [25, 50, 75])
            non_diabetic_percentiles = np.percentile(df[df['diabetes'] == 0][feature], [25, 50, 75])
            
            # Add traces for each group
            fig.add_trace(go.Scatter(
                x=['25%', '50%', '75%'],
                y=non_diabetic_percentiles,
                mode='lines+markers',
                name=f'No Diabetes - {feature}',
                line=dict(width=3, dash='dot'),
                marker=dict(size=10)
            ))
            fig.add_trace(go.Scatter(
                x=['25%', '50%', '75%'],
                y=diabetic_percentiles,
                mode='lines+markers',
                name=f'Diabetes - {feature}',
                line=dict(width=3),
                marker=dict(size=10)
            ))
            
            # Generate insights and recommendations
            diabetic_mean = df[df['diabetes'] == 1][feature].mean()
            non_diabetic_mean = df[df['diabetes'] == 0][feature].mean()
            diff_percentage = ((diabetic_mean - non_diabetic_mean) / non_diabetic_mean) * 100
            
            # Insights generation
            if feature == 'glucose':
                if diabetic_mean > 125:
                    insights.append(f"**High Blood Glucose**: Average glucose levels are elevated in diabetic group.")
                    recommendations.append("Consider regular blood sugar monitoring and consulting a healthcare professional.")
            
            elif feature == 'bmi':
                if diabetic_mean > 30:
                    insights.append(f"**Obesity Risk**: BMI is significantly higher in diabetic group.")
                    recommendations.append("Focus on weight management through diet and exercise.")
            
            elif feature == 'age':
                if diabetic_mean > 50:
                    insights.append(f"**Age-Related Risk**: Diabetic group has a higher average age.")
                    recommendations.append("Regular health check-ups and preventive screenings are crucial.")
            
            elif feature == 'blood_pressure':
                if diabetic_mean > 130:
                    insights.append(f"**Elevated Blood Pressure**: Blood pressure is higher in diabetic group.")
                    recommendations.append("Monitor blood pressure and consider lifestyle modifications.")
        
        # Customize layout
        fig.update_layout(
            title='Comparative Feature Analysis: Diabetic vs Non-Diabetic',
            xaxis_title='Percentile',
            yaxis_title='Feature Value',
            height=600,
            width=800,
            legend_title_text='Features'
        )
        
        # Display the plot
        st.plotly_chart(fig, use_container_width=True)
        
        # Display Insights and Recommendations
        st.subheader("🩺 Health Insights and Recommendations")
        
        # Insights Section
        st.markdown("### Key Insights")
        for insight in insights:
            st.markdown(f"- {insight}")
        
        # Recommendations Section
        st.markdown("### Personalized Recommendations")
        for recommendation in recommendations:
            st.markdown(f"- {recommendation}")
        
        # General Diabetes Prevention Advice
        st.markdown("""
        ### General Diabetes Prevention Tips
        - Maintain a balanced diet rich in fruits, vegetables, and whole grains
        - Engage in regular physical activity (at least 150 minutes per week)
        - Maintain a healthy body weight
        - Regular health check-ups and screenings
        - Manage stress through meditation, yoga, or counseling
        - Limit alcohol consumption and avoid smoking
        """)

    def show_loading(self):
        """Placeholder method for loading animation"""
        # You can add any pre-processing logic here if needed
        pass

    def run(self):
        # Create landing page
        st.header("🌍 Global Diabetes Insights by WHO")
        
        # Create three columns for insights
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown("### Diabetes Prevalence")
            st.info("""
            Approximately 422 million people worldwide have diabetes, with the number rising rapidly. 
            This represents a significant global health challenge affecting diverse populations.
            """)
        
        with col2:
            st.markdown("### Global Impact")
            st.warning("""
            Diabetes is a major cause of critical health complications including blindness, 
            kidney failure, heart attacks, stroke, and lower limb amputation, affecting multiple organ systems.
            """)
        
        with col3:
            st.markdown("### Economic Burden")
            st.error("""
            The global healthcare expenditure on diabetes reached USD 966 billion in 2021. 
            This massive economic impact highlights the urgent need for preventive strategies.
            """)

        # WHO Quote
        st.markdown("""
        > *"Diabetes is a silent global epidemic that requires immediate and comprehensive action."*
        > 
        > *- World Health Organization*
        """)

        # Add AI Health Assistant Section
        st.markdown("---")
        display_chat_interface()
        st.markdown("---")

        # Dataset Upload Section
        st.header("📤 Upload Dataset")
        
        # Create a centered container
        upload_container = st.container()
        with upload_container:
            col1, col2, col3 = st.columns([1, 2, 1])
            
            with col2:
                # Styled upload section with loading animation trigger
                def on_file_upload():
                    # JavaScript to show loading
                    st.markdown("""
                    <script>
                    showLoading();
                    setTimeout(hideLoading, 3000);
                    </script>
                    """, unsafe_allow_html=True)
                
                uploaded_file = st.file_uploader(
                    "Choose a CSV file", 
                    type="csv", 
                    help="Upload a CSV file for diabetes risk analysis",
                    label_visibility='collapsed',
                    on_change=on_file_upload
                )
                
                st.markdown("""
                <div class="upload-box">
                    <div class="upload-text">Drag and drop file here</div>
                    <div class="upload-subtext">Limit 200MB per file • CSV</div>
                </div>
                """, unsafe_allow_html=True)

        if uploaded_file is not None:
            # Store uploaded file in session state
            st.session_state.uploaded_file = uploaded_file
            
            # Load and preprocess data
            original_df, X, y, scaler, feature_names = self.load_and_preprocess_data(uploaded_file)
            
            if original_df is not None and X is not None and y is not None:
                # Data Visualization Section
                st.header("📊 Dataset Insights")
                self.visualize_dataset(original_df)
                
                # Diabetes Management Section
                with st.tabs("🩺 Comprehensive Diabetes Management Guide")[0]:
                    st.markdown("# 🩺 Comprehensive Diabetes Management Guide")
                    
                    # Detailed Management Sections
                    management_sections = [
                        {
                            'title': 'Blood Sugar Monitoring',
                            'emoji': '🩸',
                            'overview': """
                            Effective blood sugar monitoring is the cornerstone of diabetes management. 
                            It provides real-time insights into your metabolic health and helps prevent 
                            potential complications.
                            """,
                            'key_strategies': [
                                {
                                    'name': 'Daily Monitoring Techniques',
                                    'details': [
                                        'Use glucometer for traditional testing',
                                        'Explore continuous glucose monitoring (CGM) systems',
                                        ('Track readings at consistent times: '
                                         '- Fasting '
                                         '- Before meals '
                                         '- 2 hours after meals '
                                         '- Before bedtime')
                                    ],
                                    'recommended_devices': [
                                        'FreeStyle Libre',
                                        'Dexcom G6',
                                        'Medtronic Guardian',
                                        'Traditional Glucometers'
                                    ]
                                },
                                {
                                    'name': 'Monitoring Targets and Interpretation',
                                    'details': [
                                        'Fasting Glucose: 80-130 mg/dL',
                                        'Post-Meal Glucose: < 180 mg/dL',
                                        'HbA1c: < 7% for most adults',
                                        ('Individualized targets based on: '
                                         '- Age '
                                         '- Overall health '
                                         '- Diabetes duration '
                                         '- Presence of complications')
                                    ],
                                    'risk_levels': [
                                        {'level': 'Low Risk', 'range': '80-130 mg/dL'},
                                        {'level': 'Moderate Risk', 'range': '130-180 mg/dL'},
                                        {'level': 'High Risk', 'range': '> 180 mg/dL'}
                                    ]
                                }
                            ],
                            'consequences': [
                                {
                                    'condition': 'Hyperglycemia (High Blood Sugar)',
                                    'symptoms': [
                                        'Excessive thirst',
                                        'Frequent urination',
                                        'Blurred vision',
                                        'Fatigue',
                                        'Slow wound healing'
                                    ],
                                    'long_term_risks': [
                                        'Cardiovascular disease',
                                        'Kidney damage',
                                        'Nerve damage',
                                        'Vision problems',
                                        'Increased infection risk'
                                    ]
                                },
                                {
                                    'condition': 'Hypoglycemia (Low Blood Sugar)',
                                    'symptoms': [
                                        'Shakiness',
                                        'Sweating',
                                        'Confusion',
                                        'Dizziness',
                                        'Weakness',
                                        'Rapid heartbeat'
                                    ],
                                    'immediate_actions': [
                                        'Consume 15g fast-acting carbohydrates',
                                        'Recheck blood sugar after 15 minutes',
                                        'Have emergency glucose sources nearby'
                                    ]
                                }
                            ]
                        }
                    ]

                    # Create two columns for management sections
                    col1, col2 = st.columns([1, 1])

                    with col1:
                        # Blood Sugar Monitoring Section
                        st.markdown("## 🩸 Blood Sugar Monitoring")
                        
                        # Overview Expander
                        with st.expander("📝 Monitoring Overview"):
                            st.markdown(management_sections[0]['overview'])
                        
                        # Daily Monitoring Strategies
                        with st.expander("📊 Daily Monitoring Techniques"):
                            st.markdown("### Monitoring Methods")
                            for detail in management_sections[0]['key_strategies'][0]['details']:
                                st.markdown(f"- {detail}")
                            
                            st.markdown("\n### Recommended Devices")
                            for device in management_sections[0]['key_strategies'][0]['recommended_devices']:
                                st.markdown(f"- {device}")
                        
                        # Monitoring Targets
                        with st.expander("🎯 Monitoring Targets"):
                            st.markdown("### Glucose Level Goals")
                            for detail in management_sections[0]['key_strategies'][1]['details']:
                                st.markdown(f"- {detail}")
                            
                            st.markdown("\n### Risk Levels")
                            risk_data = management_sections[0]['key_strategies'][1]['risk_levels']
                            risk_df = pd.DataFrame(risk_data)
                            st.table(risk_df)

                    with col2:
                        # Consequences and Management
                        st.markdown("## 🚨 Blood Sugar Complications")
                        
                        # Hyperglycemia Details
                        with st.expander("📈 Hyperglycemia Insights"):
                            hyper_data = management_sections[0]['consequences'][0]
                            st.markdown(f"### {hyper_data['condition']}")
                            
                            st.markdown("#### Symptoms")
                            for symptom in hyper_data['symptoms']:
                                st.markdown(f"- {symptom}")
                            
                            st.markdown("\n#### Long-Term Risks")
                            for risk in hyper_data['long_term_risks']:
                                st.markdown(f"- {risk}")
                        
                        # Hypoglycemia Details
                        with st.expander("📉 Hypoglycemia Management"):
                            hypo_data = management_sections[0]['consequences'][1]
                            st.markdown(f"### {hypo_data['condition']}")
                            
                            st.markdown("#### Symptoms")
                            for symptom in hypo_data['symptoms']:
                                st.markdown(f"- {symptom}")
                            
                            st.markdown("\n#### Immediate Actions")
                            for action in hypo_data['immediate_actions']:
                                st.markdown(f"- {action}")

                        # Lifestyle Management
                        st.markdown("## 🌈 Holistic Lifestyle Management")
                        
                        lifestyle_tips = [
                            {
                                'category': 'Nutrition',
                                'emoji': '🥗',
                                'detailed_description': """
                                Nutrition plays a critical role in diabetes management. 
                                A well-planned diet can help stabilize blood sugar levels, 
                                improve insulin sensitivity, and reduce the risk of complications.
                                """,
                                'tips': [
                                    'Follow a low-glycemic index diet',
                                    'Increase fiber intake',
                                    'Limit processed and sugary foods',
                                    'Practice portion control',
                                    'Balance macronutrients',
                                    'Stay hydrated'
                                ],
                                'recommended_foods': [
                                    'Leafy green vegetables',
                                    'Whole grains',
                                    'Lean proteins',
                                    'Nuts and seeds',
                                    'Berries'
                                ]
                            },
                            {
                                'category': 'Physical Activity',
                                'emoji': '🏃',
                                'detailed_description': """
                                Regular physical activity is essential for diabetes management. 
                                Exercise helps improve insulin sensitivity, reduces blood sugar levels, 
                                and supports overall metabolic health.
                                """,
                                'tips': [
                                    'Aim for 150 minutes of moderate exercise weekly',
                                    'Include both cardio and strength training',
                                    'Practice regular walking',
                                    'Stay consistently active'
                                ]
                            },
                            {
                                'category': 'Stress Management',
                                'emoji': '🧘',
                                'detailed_description': """
                                Stress can significantly impact blood sugar levels and overall diabetes management. 
                                Implementing effective stress reduction techniques helps maintain metabolic balance 
                                and supports mental well-being.
                                """,
                                'tips': [
                                    'Practice daily meditation',
                                    'Ensure 7-9 hours of quality sleep',
                                    'Try yoga or mindfulness techniques',
                                    'Maintain a supportive social network'
                                ]
                            }
                        ]

                        # Render Lifestyle Tips
                        cols = st.columns(3)
                        for i, lifestyle in enumerate(lifestyle_tips):
                            with cols[i]:
                                with st.expander(f"{lifestyle['emoji']} {lifestyle['category']} Guide"):
                                    st.markdown(lifestyle['detailed_description'])
                                    st.markdown("### Key Tips")
                                    for tip in lifestyle['tips']:
                                        st.markdown(f"- {tip}")
                                    
                                    if 'recommended_foods' in lifestyle:
                                        st.markdown("### Recommended Foods")
                                        for food in lifestyle['recommended_foods']:
                                            st.markdown(f"- {food}")

                        # Emergency Management
                        st.markdown("## 🚨 Emergency Management")
                        
                        emergency_steps = [
                            {
                                'title': 'Recognize Symptoms',
                                'description': 'Learn to identify early signs of blood sugar fluctuations',
                                'details': [
                                    'Understand hyperglycemia and hypoglycemia symptoms',
                                    'Track your body\'s unique response patterns'
                                ]
                            },
                            {
                                'title': 'Emergency Preparedness',
                                'description': 'Always be ready to manage unexpected situations',
                                'details': [
                                    'Keep emergency glucose sources nearby',
                                    'Wear a medical identification bracelet',
                                    'Maintain an emergency contact list',
                                    'Know when to seek immediate medical help'
                                ]
                            }
                        ]
                        
                        with st.expander("🆘 Emergency Preparedness Guide"):
                            for step in emergency_steps:
                                st.markdown(f"### {step['title']}")
                                st.markdown(step['description'])
                                for detail in step['details']:
                                    st.markdown(f"- {detail}")

                        # Medical Disclaimer
                        st.warning("""
                        🩺 **Medical Disclaimer**: 
                        This comprehensive guide is for informational purposes only. 
                        Diabetes management is highly individualized. Always consult with 
                        healthcare professionals for personalized advice, diagnosis, 
                        and tailored treatment plans.
                        """)

class HealthReportGenerator:
    @staticmethod
    def generate_comprehensive_report(original_df, analysis_results=None):
        """
        Generate a comprehensive health report as a PDF
        
        Args:
            original_df (pd.DataFrame): Original dataset
            analysis_results (dict, optional): Additional analysis results
        
        Returns:
            bytes: PDF report content
        """
        # Create a buffer for the PDF
        buffer = io.BytesIO()
        
        # Create the PDF document
        doc = SimpleDocTemplate(buffer, pagesize=letter, 
                                rightMargin=72, leftMargin=72, 
                                topMargin=72, bottomMargin=18)
        
        # Styles
        styles = getSampleStyleSheet()
        
        # Custom styles
        title_style = ParagraphStyle(
            'Title', 
            parent=styles['Title'], 
            fontName='Helvetica-Bold', 
            fontSize=16, 
            textColor=colors.navy,
            alignment=TA_CENTER
        )
        
        subtitle_style = ParagraphStyle(
            'Subtitle', 
            parent=styles['Heading2'], 
            fontName='Helvetica', 
            fontSize=12, 
            textColor=colors.navy,
            alignment=TA_LEFT
        )
        
        normal_style = ParagraphStyle(
            'Normal', 
            parent=styles['Normal'], 
            fontName='Helvetica', 
            fontSize=10, 
            textColor=colors.black,
            alignment=TA_LEFT
        )
        
        # Story elements for the PDF
        story = []
        
        # Title
        story.append(Paragraph("Comprehensive Health Insights Report", title_style))
        story.append(Spacer(1, 12))
        
        # Patient Demographics and Basic Stats
        story.append(Paragraph("Patient Overview", subtitle_style))
        
        # Prepare demographic data
        demo_data = [
            ['Total Records', str(len(original_df))],
            ['Diabetes Prevalence', f"{original_df['diabetes'].mean()*100:.2f}%"],
            ['Age Range', f"{original_df['age'].min()} - {original_df['age'].max()} years"],
            ['Average BMI', f"{original_df['bmi'].mean():.2f}"]
        ]
        
        demo_table = Table(demo_data, colWidths=[3*inch, 2*inch])
        demo_table.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.navy),
            ('TEXTCOLOR', (0,0), (-1,0), colors.white),
            ('ALIGN', (0,0), (-1,-1), 'CENTER'),
            ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
            ('FONTSIZE', (0,0), (-1,0), 12),
            ('BOTTOMPADDING', (0,0), (-1,0), 12),
            ('BACKGROUND', (0,1), (-1,-1), colors.beige),
            ('GRID', (0,0), (-1,-1), 1, colors.black)
        ]))
        story.append(demo_table)
        story.append(Spacer(1, 12))
        
        # Health Risk Analysis
        story.append(Paragraph("Health Risk Insights", subtitle_style))
        
        # Risk Factors Analysis
        risk_factors = [
            ['Risk Factor', 'Average Value', 'Risk Level'],
            ['Glucose', f"{original_df['glucose'].mean():.2f}", 'Moderate'],
            ['Blood Pressure', f"{original_df['blood_pressure'].mean():.2f}", 'Moderate'],
            ['BMI', f"{original_df['bmi'].mean():.2f}", 'High'],
            ['Age', f"{original_df['age'].mean():.2f}", 'Variable']
        ]
        
        risk_table = Table(risk_factors, colWidths=[2*inch, 2*inch, 2*inch])
        risk_table.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.navy),
            ('TEXTCOLOR', (0,0), (-1,0), colors.white),
            ('ALIGN', (0,0), (-1,-1), 'CENTER'),
            ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
            ('FONTSIZE', (0,0), (-1,0), 12),
            ('BOTTOMPADDING', (0,0), (-1,0), 12),
            ('BACKGROUND', (0,1), (-1,-1), colors.beige),
            ('GRID', (0,0), (-1,-1), 1, colors.black)
        ]))
        story.append(risk_table)
        story.append(Spacer(1, 12))
        
        # Recommendations Section
        story.append(Paragraph("Health Recommendations", subtitle_style))
        
        recommendations = [
            "Maintain a balanced diet with low glycemic index foods",
            "Engage in regular physical activity (150 minutes/week)",
            "Monitor blood glucose levels consistently",
            "Maintain a healthy BMI through diet and exercise",
            "Regular medical check-ups and screenings"
        ]
        
        for rec in recommendations:
            story.append(Paragraph(f"• {rec}", normal_style))
        
        # Medical Disclaimer
        story.append(Spacer(1, 12))
        story.append(Paragraph("Medical Disclaimer: This report is for informational purposes only. " +
                               "Always consult healthcare professionals for personalized medical advice.", 
                               ParagraphStyle(
                                   'Disclaimer', 
                                   parent=styles['Normal'], 
                                   fontName='Helvetica', 
                                   fontSize=8, 
                                   textColor=colors.gray,
                                   alignment=TA_CENTER
                               )))
        
        # Build PDF
        doc.build(story)
        
        # Get the value of the BytesIO buffer
        pdf_bytes = buffer.getvalue()
        buffer.close()
        
        return pdf_bytes

    @staticmethod
    def create_download_link(pdf_bytes, filename="health_insights_report.pdf"):
        """
        Create a downloadable link for the PDF
        
        Args:
            pdf_bytes (bytes): PDF content
            filename (str): Filename for download
        
        Returns:
            str: Base64 encoded download link
        """
        b64 = base64.b64encode(pdf_bytes).decode()
        href = f'<a href="data:application/pdf;base64,{b64}" download="{filename}">Download Health Report</a>'
        return href

def main():
    # Initialize session state
    if 'uploaded_file' not in st.session_state:
        st.session_state.uploaded_file = None
    if 'original_data' not in st.session_state:
        st.session_state.original_data = None
    if 'model_trained' not in st.session_state:
        st.session_state.model_trained = False
        st.session_state.model = None
        st.session_state.scaler = None
        st.session_state.label_encoder = None
        st.session_state.feature_names = None

    app = SmartDiabeticAnalysis()
    
    # Add report generation option if dataset is uploaded
    if st.session_state.uploaded_file is not None:
        # Create a container for report generation
        report_container = st.container()
        
        with report_container:
            # Enhanced styling for report section
            st.markdown("""
            <style>
            .report-section {
                background-color: rgba(46, 204, 113, 0.1);
                border-radius: 15px;
                padding: 20px;
                margin-top: 20px;
                border: 2px solid #2ecc71;
                transition: all 0.3s ease;
            }
            .report-section:hover {
                box-shadow: 0 5px 15px rgba(46, 204, 113, 0.3);
                transform: translateY(-5px);
            }
            .report-button {
                background-color: #2ecc71 !important;
                color: white !important;
                font-weight: bold !important;
                border-radius: 10px !important;
                padding: 10px 20px !important;
                transition: all 0.3s ease !important;
                width: 100% !important;
                display: inline-block !important;
                text-align: center !important;
            }
            .report-button:hover {
                background-color: #27ae60 !important;
                transform: scale(1.02) !important;
                box-shadow: 0 4px 10px rgba(0,0,0,0.2) !important;
            }
            </style>
            """, unsafe_allow_html=True)
            
            # Report generation section with improved visibility
            st.markdown('<div class="report-section">', unsafe_allow_html=True)
            
            st.markdown("## 📄 Comprehensive Health Report")
            st.markdown("Generate a detailed PDF report summarizing your health insights and analysis.")
            
            # Generate report button with enhanced styling
            report_col1, report_col2, report_col3 = st.columns([1,3,1])
            
            with report_col2:
                generate_report = st.button(
                    "🔬 Generate Comprehensive Health Report", 
                    key="generate_report_btn_main", 
                    help="Click to create a downloadable PDF with your health analysis",
                    use_container_width=True
                )
            
            # Process report generation
            if generate_report:
                try:
                    # Load the original dataset
                    original_df = st.session_state.original_data
                    
                    # Generate report
                    report_bytes = HealthReportGenerator.generate_comprehensive_report(original_df)
                    
                    # Create download link
                    download_link = HealthReportGenerator.create_download_link(report_bytes)
                    
                    # Display download link with success message
                    st.success("🎉 Your comprehensive health report has been generated!")
                    st.markdown(download_link, unsafe_allow_html=True)
                
                except Exception as e:
                    st.error(f"Error generating report: {e}")
            
            st.markdown('</div>', unsafe_allow_html=True)
    
    app.run()

if __name__ == "__main__":
    main() 

# 🩺 Smart Diabetic Analysis

## Overview
A beginner-friendly Streamlit application for smart diabetic risk analysis using XGBoost.

## 🚀 Quick Start

### Prerequisites
- Python 3.8+
- pip (Python package manager)

### Installation
```bash
pip install streamlit pandas numpy scikit-learn matplotlib seaborn xgboost plotly
```

### Running the Application
```bash
streamlit run src/app.py
```

## 📊 How to Use
1. Upload your CSV dataset
2. Explore Dataset Insights
3. Click "Train XGBoost Model"
4. Explore model performance graphs
5. Enter health parameters to predict diabetes risk

## 🖥️ Key Features
- Interactive Dataset Visualization
- Comprehensive Data Analysis
- XGBoost Model Training
- Real-time Risk Prediction

### 🌈 Dataset Visualization Tabs
1. **Distribution Tab**
   - Histogram of features
   - Comparison between diabetic and non-diabetic groups
   - Frequency and value distribution

2. **Correlation Tab**
   - Heatmap of feature correlations
   - Identify relationships between variables
   - Color-coded correlation intensity

3. **Box Plots Tab**
   - Detailed feature distributions
   - Outlier identification
   - Comparison between diabetic and non-diabetic groups

### 📈 Variable Relationships
- Line graph comparing feature values
- Diabetic vs. Non-Diabetic groups
- Insights into feature differences
- Percentage change analysis

### Additional Insights
- Pie chart of diabetes distribution
- Basic statistical summary
- Interactive and responsive graphs

## 📝 Notes for Beginners
- Ensure your CSV has a 'diabetes' column
- Categorical columns will be automatically encoded
- Features will be scaled before model training

## 🤝 Support
Having trouble? Check the requirements or create an issue. 
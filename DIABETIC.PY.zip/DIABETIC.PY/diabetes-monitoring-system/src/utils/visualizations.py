import matplotlib.pyplot as plt
import seaborn as sns

def plot_feature_importance(importances, feature_names):
    """
    Plots the feature importance from the XGBoost model.
    
    Parameters:
    importances (array): Array of feature importances.
    feature_names (list): List of feature names.
    """
    indices = importances.argsort()[::-1]
    plt.figure(figsize=(10, 6))
    plt.title("Feature Importances")
    plt.bar(range(len(importances)), importances[indices], align="center")
    plt.xticks(range(len(importances)), [feature_names[i] for i in indices], rotation=90)
    plt.xlim([-1, len(importances)])
    plt.tight_layout()
    plt.show()

def plot_performance_metrics(metrics):
    """
    Plots performance metrics of the model.
    
    Parameters:
    metrics (dict): Dictionary containing performance metrics like accuracy, precision, recall, etc.
    """
    plt.figure(figsize=(10, 6))
    sns.barplot(x=list(metrics.keys()), y=list(metrics.values()))
    plt.title("Model Performance Metrics")
    plt.ylabel("Score")
    plt.xlabel("Metrics")
    plt.ylim(0, 1)
    plt.tight_layout()
    plt.show()
diabetes-monitoring-system
├── src
│   ├── app.py
│   ├── models
│   │   ├── predictor.py
│   │   └── xgboost_model.py
│   ├── data
│   │   └── data_processor.py
│   ├── utils
│   │   ├── visualizations.py
│   │   └── helpers.py
│   └── config
│       └── settings.py
├── tests
│   ├── __init__.py
│   ├── test_predictor.py
│   └── test_data_processor.py
├── requirements.txt
└── README.md
import pytest
import pandas as pd
from src.data.data_processor import load_data, preprocess_data

def test_load_data():
    df = load_data('path/to/test/data.csv')
    assert isinstance(df, pd.DataFrame)
    assert not df.empty

def test_preprocess_data():
    df = pd.DataFrame({
        'feature1': [1, 2, None],
        'feature2': ['A', 'B', 'A'],
        'target': [0, 1, 0]
    })
    processed_df = preprocess_data(df)
    assert 'feature1' in processed_df.columns
    assert processed_df['feature1'].isnull().sum() == 0
    assert processed_df['feature2'].nunique() == 2
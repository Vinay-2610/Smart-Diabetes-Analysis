import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler

def generate_diabetes_dataset(n_samples=1000):
    np.random.seed(42)
    
    # Generate features with realistic distributions for Indian context
    age = np.random.normal(45, 15, n_samples)  # Mean age around 45
    bmi = np.random.normal(25, 5, n_samples)  # Average BMI
    
    # Glucose levels
    glucose = np.random.normal(110, 25, n_samples)
    
    # Blood pressure
    blood_pressure = np.random.normal(130, 20, n_samples)
    
    # Insulin levels
    insulin = np.random.normal(20, 10, n_samples)
    
    # Diabetes Pedigree Function (genetic influence)
    diabetes_pedigree = np.random.normal(0.5, 0.3, n_samples)
    
    # Categorical features
    gender = np.random.choice(['Male', 'Female'], n_samples)
    smoking_status = np.random.choice(['Non-smoker', 'Light Smoker', 'Heavy Smoker'], n_samples)
    physical_activity = np.random.choice(['Sedentary', 'Moderate', 'Active'], n_samples)
    
    # Synthetic diabetes risk calculation
    diabetes_risk = (
        0.5 * (age > 45) + 
        0.3 * (bmi > 25) + 
        0.4 * (glucose > 125) + 
        0.2 * (blood_pressure > 140) + 
        0.3 * (insulin > 25) + 
        0.2 * (diabetes_pedigree > 0.7) +
        0.1 * (smoking_status == 'Heavy Smoker') +
        0.1 * (physical_activity == 'Sedentary')
    )
    
    # Binary diabetes target
    diabetes = (diabetes_risk > np.median(diabetes_risk)).astype(int)
    
    # Create DataFrame
    df = pd.DataFrame({
        'age': age,
        'bmi': bmi,
        'glucose': glucose,
        'blood_pressure': blood_pressure,
        'insulin': insulin,
        'diabetes_pedigree': diabetes_pedigree,
        'gender': gender,
        'smoking_status': smoking_status,
        'physical_activity': physical_activity,
        'diabetes': diabetes
    })
    
    return df

# Generate and save the dataset
dataset = generate_diabetes_dataset()
dataset.to_csv('data/diabetes_monitoring_realistic_indian_household.csv', index=False)
print("Dataset generated successfully!")

logo_path = "logos/kalasalingam_logo.png" 

with tab2:
    st.markdown("# 📊 Risk Calculation Methodology")
    
    # Risk Factors
    risk_factors = [
        {
            'emoji': '🩸',
            'title': 'Glucose Levels',
            'weight': 30
        },
        {
            'emoji': '📏',
            'title': 'Body Mass Index (BMI)',
            'weight': 25
        },
        {
            'emoji': '🕰️',
            'title': 'Age',
            'weight': 20
        },
        {
            'emoji': '❤️',
            'title': 'Blood Pressure',
            'weight': 15
        }
    ]

    # Render Risk Factors
    for factor in risk_factors:
        with st.expander(f"{factor['emoji']} {factor['title']} (Weight: {factor['weight']}%)"):
            st.write(f"Risk weight for {factor['title']}: {factor['weight']}%")

    # Risk Calculation Function
    def calculate_risk_score(glucose, bmi, age, blood_pressure):
        def calculate_glucose_risk(glucose):
            if glucose > 125: return 30
            if glucose > 100: return 15
            return 0

        def calculate_bmi_risk(bmi):
            if bmi > 30: return 25
            if bmi > 25: return 15
            return 0

        def calculate_age_risk(age):
            if age > 50: return 20
            if age > 40: return 10
            return 0

        def calculate_bp_risk(bp):
            if bp > 140: return 15
            if bp > 130: return 10
            return 0

        total_score = (
            calculate_glucose_risk(glucose) +
            calculate_bmi_risk(bmi) +
            calculate_age_risk(age) +
            calculate_bp_risk(blood_pressure)
        )
        return total_score

    # Medical Disclaimer
    st.warning("""
    🩺 **Medical Disclaimer**: 
    This risk assessment is a general guide and should not replace professional medical advice. 
    Always consult with a healthcare provider for personalized medical guidance.
    """) 